/**
 * Desktop Mode type definitions.
 *
 * @since 6.9.0
 */

/**
 * Window state enum.
 */
export type WindowState = 'normal' | 'maximized' | 'minimized' | 'fullscreen' | 'snapped-left' | 'snapped-right';

/**
 * A virtual desktop ("Space" in macOS terminology).
 *
 * Each desktop owns its own set of windows. Only one desktop is
 * "active" at a time; the active desktop's windows are visible, every
 * other desktop's windows stay mounted but display-suppressed so
 * switching is instant and doesn't lose iframe state.
 *
 * @public
 */
export interface Desktop {
	/** Unique identifier — `default-1`, `desktop-2`, … */
	id: string;
	/** Human-readable label, shown beneath the overview top-bar tile. */
	label: string;
}

/**
 * Configuration for a desktop window.
 */
export interface WindowConfig {
	/** Unique window identifier, derived from the admin page slug. */
	id: string;
	/**
	 * Virtual-desktop assignment. When omitted on construction, the
	 * window joins the manager's currently active desktop. Mutated by
	 * the manager's switch / close logic when desktops are reorganised.
	 */
	desktopId?: string;
	/**
	 * Grouping key shared across every instance of the same admin page.
	 * For the first instance `baseId` equals `id`; additional instances
	 * carry suffixed ids (`${baseId}-2`, `${baseId}-3`, ...) while keeping
	 * the same baseId so the dock can group them.
	 */
	baseId?: string;
	/**
	 * Whether this page supports multiple simultaneous windows. When true,
	 * the title-bar menu exposes an "Open another" action and the dock
	 * icon gets a secondary "+" tap target. Singletons (false/undefined)
	 * always reuse the existing window.
	 */
	multi?: boolean;
	/**
	 * The admin page URL to load in the iframe.
	 *
	 * Optional for **native windows** (`native: true`) because a
	 * native window renders into `body` via {@link WindowConfig.render}
	 * rather than loading a URL. Iframe windows still require it —
	 * an iframe without a `src` serves `about:blank` and the user
	 * sees nothing useful. The shell defaults an absent native `url`
	 * to `#<id>` so history / bookmarking still round-trip to
	 * something unique.
	 */
	url?: string;
	/** Window title displayed in the title bar. */
	title: string;
	/** Dashicon class for the window icon (e.g., 'dashicons-admin-post'). */
	icon: string;
	/** Initial x position in pixels. */
	x: number;
	/** Initial y position in pixels. */
	y: number;
	/** Initial width in pixels. */
	width: number;
	/** Initial height in pixels. */
	height: number;
	/** Minimum width in pixels. */
	minWidth: number;
	/** Minimum height in pixels. */
	minHeight: number;
	/**
	 * Submenu items that render as a tab strip below the title bar.
	 * Each tab navigates the iframe within the same window — no new window opens.
	 * Pass an empty array (or omit) to hide the strip.
	 */
	submenu?: { title: string; url: string }[];
	/**
	 * Optional initial state. When present, the window is constructed
	 * into this state directly — used by session restore so a minimized
	 * or maximized window comes back in the same shape the user left it.
	 */
	initialState?: WindowState;
	/**
	 * Native window flag. When true, the window's body is rendered
	 * directly in the parent DOM via {@link WindowConfig.render} instead
	 * of loading {@link WindowConfig.url} in an iframe. Native windows
	 * inherit the full chrome (drag/resize/minimize/maximize) but skip
	 * iframe-only affordances (detach-to-tab, screen-meta bridge, tab
	 * strip, postMessage listener). Used for desktop-shell-native panels
	 * like OS Settings where an iframe would be wasteful and where the
	 * module wants direct access to the shell.
	 */
	native?: boolean;
	/**
	 * Render callback for native windows. Invoked once after the window
	 * element mounts; receives the empty `.wp-desktop-window__body` and
	 * fills it with whatever DOM the module wants. Ignored when
	 * `native` is falsy.
	 */
	render?: ( body: HTMLElement ) => void;
	/**
	 * Auto-focus control for native windows. Pass `true` to focus
	 * the body element itself (tabbable after render), a CSS
	 * selector string to focus a specific child (e.g. `'input'` for
	 * a search window, `'[data-primary]'` for a calculator's `=`
	 * key), or omit / pass `false` to skip auto-focus entirely.
	 *
	 * Applied on the next animation frame after `render()` returns —
	 * gives the DOM a chance to settle before `.focus()` resolves.
	 * Ignored for iframe windows (the iframe's own focus handling
	 * already owns that surface).
	 */
	autofocus?: boolean | string;
	/**
	 * Inline callback fired when the window's close animation begins.
	 * Complements the `wp-desktop.window.closing` hook — the hook is
	 * broadcast to every subscriber, while this callback is scoped
	 * specifically to this window's caller. Native windows use it to
	 * tear down subscriptions / timers that don't want to live past
	 * the fade-out. No-op for iframe windows.
	 */
	onClose?: () => void;
	/**
	 * Inline callback fired whenever the body element's dimensions
	 * change (user resize, initial mount, viewport reflow). Native
	 * windows that paint their own canvas use this to re-measure;
	 * DOM-based content usually doesn't need it. Delivered width /
	 * height are the `.wp-desktop-window__body` client dimensions,
	 * NOT the outer window size (title bar + tab strip are already
	 * subtracted). Fires alongside the
	 * `wp-desktop.window.body-resized` hook.
	 */
	onResize?: ( width: number, height: number ) => void;
}

/**
 * Narrowed window configuration for **native** windows only. Author-
 * facing alias that defaults `native: true` and drops the iframe-only
 * fields the full {@link WindowConfig} carries. Use this when
 * declaring a plugin's native window:
 *
 * ```ts
 * const calc: NativeWindowDef = {
 *   id: 'calc',
 *   title: 'Calculator',
 *   icon: 'dashicons-calculator',
 *   width: 320,
 *   height: 460,
 *   minWidth: 280,
 *   minHeight: 380,
 *   render: ( body ) => { body.innerHTML = '…'; },
 *   onResize: ( w, h ) => console.log( 'body:', w, h ),
 * };
 * wp.desktop.registerWindow( calc );
 * ```
 *
 * @public
 * @since 0.10.0
 */
export interface NativeWindowDef extends Omit< WindowConfig, 'native' | 'url' | 'submenu' | 'x' | 'y' > {
	/** Optional `#hash`-style URL for history. Auto-generated from `id` when absent. */
	url?: string;
	/** Always `true` for native windows. Accepted for clarity; the shell enforces it. */
	native?: true;
	/** Initial x position in pixels. Defaults to 0; the shell's cascade positioner usually takes over. */
	x?: number;
	/** Initial y position in pixels. Defaults to 0; the shell's cascade positioner usually takes over. */
	y?: number;
}

/**
 * Canonical shape for a single entry displayed in a monitor /
 * observability widget. Any plugin that wants to contribute an
 * entry to monitor widgets applies a `wp-desktop.monitor.entry`
 * filter returning a mutated `MonitorEntry` or adds one to the
 * aggregated list. By converging every plugin on this shape we
 * avoid the "every monitor widget invents its own schema" fragmentation.
 *
 * Optional fields are all present so callers can filter / group
 * consistently: a pure console-log entry leaves `status` / `method`
 * / `url` unset, while a failed XHR fills them all.
 *
 * @public
 * @since 0.10.0
 */
export interface MonitorEntry {
	/** Unix timestamp in milliseconds (Date.now()). */
	ts: number;
	/** Classification tag — used for coloring / grouping in monitor UIs. */
	type: 'log' | 'warn' | 'error' | 'network' | 'shell-error' | 'iframe-error' | string;
	/** Human-readable summary. Max ~240 chars in UI — callers may truncate. */
	message: string;
	/**
	 * Free-form source label: window id, widget id, plugin slug,
	 * file:line, etc. Monitors group by this when rendering lists.
	 */
	source?: string;
	/** HTTP status (network entries). 0 when the request never completed. */
	status?: number;
	/** HTTP method (network entries). Uppercase. */
	method?: string;
	/** URL (network entries). Cross-origin is fine — monitors decide whether to render. */
	url?: string;
	/** Duration in milliseconds (network entries). */
	duration?: number;
	/** True when the entry represents a failure — network non-2xx, caught exception. */
	failed?: boolean;
	/** Arbitrary extra context. Kept untyped on purpose — MonitorEntry should stay small. */
	extra?: Record<string, unknown>;
}

/**
 * Server-declared native-window entry passed from PHP via the
 * `nativeWindows` config field. One entry per
 * `wp_register_desktop_window()` call. The shell automatically
 * adds + removes tiles to match this list across boots AND mid-
 * session plugin activation / deactivation — so activating a
 * plugin that registered via this helper makes its tile appear
 * without a browser reload, and deactivating it makes the tile
 * disappear cleanly.
 *
 * @public
 * @since 0.10.0
 */
export interface NativeWindowServerEntry {
	/** Window id + dock-tile id. */
	id: string;
	/** Tooltip + window title. */
	title: string;
	/** Dashicons class or URL. */
	icon: string;
	/** 'dock' | 'taskbar' | 'none'. */
	placement: 'dock' | 'taskbar' | 'none';
	/** Initial window dimensions in px. */
	width: number;
	height: number;
	/** Minimum user-resizable dimensions in px. */
	minWidth: number;
	minHeight: number;
	/** Autofocus rule — true, CSS selector, or false/absent. */
	autofocus: boolean | string;
	/** DOM id of the `<template>` the shell clones into the window body. */
	templateId: string;
	/** Pre-rendered template HTML. Shell injects a `<template>` when the id isn't already in the DOM (mid-session activation path). */
	templateHtml: string;
	/** Absolute URL of the plugin's enqueued script. Shell dynamically loads it when this entry appears mid-session. Empty when the plugin declared no script. */
	scriptUrl: string;
	/** WordPress script handle (informational). */
	scriptHandle: string;
	/**
	 * Tab descriptors for this window. Always includes at least the
	 * main tab (whose `template` renders the window's own body); if
	 * additional tabs were registered via
	 * `wp_register_desktop_window_tab()` they follow in position
	 * order. Empty array is equivalent to "main tab only" — the
	 * shell renders the window body directly without a tab strip.
	 *
	 * The template HTML already carries the rendered tab markup
	 * (`<wpd-tabs>` + `<wpd-tabpanel>` per entry). This field is
	 * metadata — useful for plugins that want to inspect or extend
	 * a window's tab list without re-parsing the template.
	 *
	 * @since 0.11.0
	 */
	tabs?: NativeWindowTabEntry[];
}

/**
 * A single tab descriptor on a native window — either the main tab
 * (`isMain: true`) whose template is the window's own body, or a
 * registered `wp_register_desktop_window_tab()` entry.
 *
 * @public
 * @since 0.11.0
 */
export interface NativeWindowTabEntry {
	value: string;
	label: string;
	isMain: boolean;
	/** Absolute URL of this tab's script — empty for the main tab and for tabs without a dedicated script. */
	scriptUrl: string;
	/** WordPress script handle (informational). */
	scriptHandle: string;
}

/**
 * Server-declared desktop-widget entry passed from PHP via the
 * `serverWidgets` config field. One entry per
 * `wp_register_desktop_widget()` call.
 *
 * The mount callback itself is not serializable; plugins register
 * it on `window.wpDesktopWidgets[ <id> ]` as a `(container, ctx)
 * => teardown` function. The shell pairs that global with the
 * metadata here to build a full `WidgetDef` at registration time.
 *
 * Mid-session activation injects the plugin's script (from
 * `scriptUrl`) before reading the callback, so newly-activated
 * plugins surface in the widget picker without a shell reload.
 *
 * @public
 * @since 0.10.0
 */
export interface DesktopWidgetServerEntry {
	id: string;
	label: string;
	description: string;
	icon: string;
	movable: boolean;
	resizable: boolean;
	minWidth: number;
	minHeight: number;
	maxWidth: number;
	maxHeight: number;
	defaultWidth: number;
	defaultHeight: number;
	/** Absolute URL of the plugin's enqueued script. Empty when no script was declared. */
	scriptUrl: string;
	/** WordPress script handle (informational). */
	scriptHandle: string;
}

/**
 * Server-declared wallpaper entry passed from PHP via
 * `serverWallpapers`. One entry per
 * `wp_register_desktop_wallpaper()` call. Only metadata crosses
 * the wire; the plugin's mount / resolveValue / renderEditor
 * callbacks are announced via
 * `window.wpDesktopWallpapers[ <id> ]` as a full `WallpaperDef`,
 * which the shell loads (if the script isn't yet in the tab) and
 * forwards to the normal wallpaper registry.
 *
 * @public
 * @since 0.10.0
 */
export interface DesktopWallpaperServerEntry {
	id: string;
	label: string;
	preview: string;
	type: 'css' | 'canvas';
	/**
	 * CSS value applied to the wallpaper surface. Populated when
	 * `type === 'css'` and the server-side registration passed a
	 * `value`. Empty string for canvas wallpapers, whose runtime
	 * value lives on the JS side inside the `mount` callback.
	 *
	 * When set, the shell can register the wallpaper purely from
	 * the server-side entry without any accompanying JS bundle.
	 *
	 * @since 0.11.0
	 */
	value: string;
	/** Absolute URL of the plugin's enqueued script. Empty when no script was declared. */
	scriptUrl: string;
	/** WordPress script handle (informational). */
	scriptHandle: string;
}

/**
 * Server-declared command-script entry passed from PHP via
 * `serverCommandScripts`. One entry per
 * `wp_desktop_register_command_script()` call (or indirectly via
 * `wp_register_desktop_command()`).
 *
 * The shell injects each `scriptUrl` into the shell page on mid-
 * session plugin activation. The loaded script registers its commands
 * through the normal `wp.desktop.registerCommand()` path; the live
 * command-registry subscription (see `subscribeCommands`) then repaints
 * any open palette without a reload.
 *
 * @public
 * @since 0.15.0
 */
export interface DesktopCommandScriptServerEntry {
	/** WordPress script handle — doubles as the command `owner` key used for live unregistration. */
	handle: string;
	/** Absolute URL of the plugin's enqueued script. Empty entries are dropped by the PHP payload builder. */
	scriptUrl: string;
}

/**
 * Server-declared command metadata passed from PHP via
 * `serverCommands`. Optional companion to
 * `DesktopCommandScriptServerEntry` — plugins declaring commands with
 * `wp_register_desktop_command()` emit one entry per command so metadata
 * is enumerable without executing the plugin's JS. The `run` function
 * still lives JS-side and is attached by the script referenced in
 * `scriptUrl` when it loads.
 *
 * Advisory today — reserved for future pre-registration shims.
 *
 * @public
 * @since 0.15.0
 */
export interface DesktopCommandServerEntry {
	slug: string;
	label: string;
	description: string;
	icon: string;
	hint: string;
	/** Absolute URL of the plugin's enqueued script. Empty when no script was declared. */
	scriptUrl: string;
	/**
	 * WordPress script handle this command belongs to. Enables live-
	 * unregistration on plugin deactivation without requiring the plugin
	 * to set `owner` on each JS `registerCommand` call — the sync walks
	 * the previous payload's slug→handle mapping when a handle leaves.
	 *
	 * @since 0.15.0
	 */
	scriptHandle: string;
}

/**
 * Server-declared desktop icon — a shortcut tile on the wallpaper
 * that opens a native window or a URL on click. Registered via PHP
 * with `wp_register_desktop_icon()`.
 *
 * @since 0.11.0
 * @public
 */
export interface DesktopIconServerEntry {
	id: string;
	title: string;
	icon: string;
	/** Id of a registered native window to open on click. Empty string when the icon targets a URL instead. */
	window: string;
	/** URL to open on click. Empty string when the icon targets a native window. */
	url: string;
	/** Sort order; lower renders first. */
	position: number;
}

/**
 * Live geometry + state snapshot for a single window, returned by
 * `WindowManager.getVisibleRects()`.
 *
 * The shape is intentionally small and non-serializable (it carries
 * a live `HTMLElement` reference) — it exists for runtime overlays
 * and collision-aware wallpaper plugins, not for persistence. For the
 * persisted shape see {@link WindowSnapshot}.
 *
 * @public
 */
export interface VisibleWindowRect {
	/** Unique window id — matches `Window.id`. */
	windowId: string;
	/**
	 * Current geometry in desktop-area coordinates (matches the
	 * window element's inline-style `left` / `top` / `width` /
	 * `height`). For windows on a suppressed (non-active) virtual
	 * desktop this still reflects the geometry the window would
	 * paint at once its desktop becomes active.
	 */
	rect: { x: number; y: number; width: number; height: number };
	/** The window's current state. Callers typically filter on this. */
	state: WindowState;
	/** Live reference to the outer window element. */
	element: HTMLElement;
}

/**
 * Serialized window state for persistence.
 */
export interface WindowSnapshot {
	id: string;
	url: string;
	title: string;
	icon: string;
	x: number;
	y: number;
	width: number;
	height: number;
	state: WindowState;
}

/**
 * A dock item passed from PHP menu data.
 */
export interface DockItemConfig {
	/** Unique identifier (menu slug). */
	id: string;
	/** Display label. */
	title: string;
	/** Icon: dashicons class, data:image/svg+xml, URL, or 'none'. */
	icon: string;
	/** Admin page URL. */
	url: string;
	/** Badge count (updates, comments, etc.). */
	badge: number;
	/** Submenu items. */
	submenu: { title: string; url: string }[];
	/**
	 * Whether this admin page supports multiple open windows. Determined
	 * server-side — list screens (Posts, Pages, Media, Users, Comments,
	 * taxonomies) are true by default; Settings / Tools / Dashboard are
	 * false. Filterable via `wp_desktop_dock_item_multi`.
	 */
	multi?: boolean;
	/**
	 * Server-side routing hint: `'dock'` for core WordPress menus
	 * rendered on the left-edge dock, `'taskbar'` for plugin-
	 * contributed top-level menus rendered in the bottom taskbar.
	 * Derived by `wpdm_dock_placement` in PHP; filterable via the
	 * `wp_desktop_dock_placement` hook.
	 */
	placement?: 'dock' | 'taskbar';
}

/**
 * A single persisted window entry.
 *
 * Shape mirrors the server-side sanitizer in includes/session.php — any
 * field added here must be validated server-side or it will be dropped.
 */
export interface SessionWindow {
	id: string;
	/**
	 * Grouping key for multi-instance windows. Optional for back-compat
	 * with sessions saved before the field existed — restore falls back
	 * to the id when missing.
	 */
	baseId?: string;
	/**
	 * Virtual-desktop assignment. Optional for back-compat with
	 * sessions saved before multi-desktop support — restore falls back
	 * to the active desktop when missing.
	 */
	desktopId?: string;
	url: string;
	title: string;
	icon: string;
	state: WindowState;
	x: number;
	y: number;
	width: number;
	height: number;
	/**
	 * External-link sub-tabs open on this window at save time. Each
	 * carries the URL and display label so the shell can re-add them
	 * via `Window.addExternalTab` on restore. Empty or absent when no
	 * external tabs are open.
	 */
	externalTabs?: { url: string; label: string }[];
}

/**
 * The user's saved desktop session — open windows, focused id, last-write
 * timestamp. Restored by the shell on load; written back debounced.
 *
 * `desktops` + `activeDesktop` are post-multi-desktop additions and
 * carry sane defaults from the server side, so older clients reading
 * a fresh session never miss them.
 */
export interface Session {
	windows: SessionWindow[];
	desktops: Desktop[];
	activeDesktop: string;
	focused: string;
	updated: number;
}

/**
 * Desktop shell configuration passed from PHP via wp_localize_script.
 */
export interface DesktopConfig {
	/** The current admin page URL (to auto-open in the first window). */
	currentPage: string;
	/** The current admin page title. */
	currentTitle: string;
	/** The current admin page icon class. */
	currentIcon: string;
	/** Base admin URL (e.g., 'http://localhost:8889/wp-admin/'). */
	adminUrl: string;
	/** The active color scheme slug. */
	colorScheme: string;
	/**
	 * Dock items derived from the admin menu and filtered to CORE
	 * WordPress pages (Dashboard, Posts, Plugins, Users, Settings,
	 * and CPTs). Rendered on the left-edge dock.
	 */
	dockItems: DockItemConfig[];
	/**
	 * Plugin-contributed top-level menus (anything routed through
	 * `admin.php?page=*`). Rendered in the bottom taskbar, macOS-
	 * style. Split from `dockItems` by `wpdm_dock_placement` in PHP
	 * with the `wp_desktop_dock_placement` filter as an escape hatch
	 * for plugins that want to override the default heuristic.
	 */
	taskbarItems: DockItemConfig[];
	/**
	 * Server-declared native windows (from `wp_register_desktop_window()`).
	 * Shell auto-registers system tiles at boot + syncs them on every
	 * live menu refresh so plugin activate / deactivate maps to tile
	 * add / remove with no browser reload.
	 */
	nativeWindows: NativeWindowServerEntry[];
	/**
	 * Server-declared widgets (from `wp_register_desktop_widget()`).
	 * Same lifecycle story as native windows — shell syncs the
	 * widget registry + dynamically loads plugin scripts on mid-
	 * session activation, so widgets appear in the picker without
	 * a browser reload.
	 */
	serverWidgets: DesktopWidgetServerEntry[];
	/**
	 * Server-declared wallpapers (from `wp_register_desktop_wallpaper()`).
	 * Same lifecycle as widgets + native windows — shell loads the
	 * plugin's JS, reads the full `WallpaperDef` from the global,
	 * and registers it. Deactivation unregisters + re-applies the
	 * current selection.
	 */
	serverWallpapers: DesktopWallpaperServerEntry[];
	/**
	 * Script handles opted-in via `wp_desktop_register_command_script()`.
	 * Shell injects each URL on boot and on mid-session activation so
	 * new slash-commands appear in the palette without a reload.
	 *
	 * @since 0.15.0
	 */
	serverCommandScripts?: DesktopCommandScriptServerEntry[];
	/**
	 * Server-declared command metadata (from `wp_register_desktop_command()`).
	 * Advisory today — reserved for future pre-registration shims.
	 *
	 * @since 0.15.0
	 */
	serverCommands?: DesktopCommandServerEntry[];
	/**
	 * Server-declared desktop icons (from `wp_register_desktop_icon()`).
	 * The shell renders these as shortcut tiles on the wallpaper;
	 * click-through opens either the referenced native window (if
	 * `window` is set) or the URL (if `url` is set).
	 *
	 * @since 0.11.0
	 */
	desktopIcons?: DesktopIconServerEntry[];
	/** Previously saved session (may be empty on first run). */
	session: Session;
	/** REST endpoint for reading/writing the session. */
	sessionUrl: string;
	/** REST endpoint for media uploads (wp/v2/media). */
	mediaUrl: string;
	/**
	 * REST endpoint returning the live admin-menu split
	 * (`{ dockItems, taskbarItems }`). The shell calls it after the
	 * chromeless bridge signals `wp-desktop-plugins-changed` so
	 * newly-activated plugins surface on the taskbar without a full
	 * tab reload. Same payload shape as `dockItems` + `taskbarItems`
	 * at boot.
	 */
	menuUrl: string;
	/** REST endpoint for saving the default-window preference. */
	defaultWindowUrl: string;
	/**
	 * Current default-window preference.
	 *
	 * - `enabled: true`  — on portal entry with no saved session,
	 *   open the window at `url`. First-run default is Dashboard.
	 * - `enabled: false` — on portal entry with no saved session, do
	 *   NOT auto-open anything. The user gets a clean empty desktop.
	 *   `url` still carries a sensible fallback (typically Dashboard)
	 *   that the portal forwards through at the HTTP layer; the shell
	 *   uses the flag to decide whether to auto-open it.
	 */
	defaultWindow: { enabled: boolean; url: string };
	/** Whether the user has the `upload_files` capability. */
	canUpload: boolean;
	/**
	 * Plugin base URL without trailing slash. Used by the shell to
	 * locate vendor assets (e.g. `${pluginUrl}/assets/vendor/pixi.min.js`)
	 * and by third-party plugin authors who want to build asset URLs
	 * relative to the wp-desktop-mode install.
	 */
	pluginUrl: string;
	/** Nonce for the REST endpoint (X-WP-Nonce header). */
	restNonce: string;
	/** Canonical `/wp-desktop/` URL — used for history.replaceState. */
	portalUrl: string;
	/** True when the shell was reached via the portal redirect. */
	fromPortal: boolean;
	/**
	 * Accent swatches shown in the OS Settings color picker. Filterable
	 * server-side via `wp_desktop_accent_colors`. Optional — the TS
	 * side falls back to a built-in default list when this is missing
	 * (older PHP builds, hostile filter that returned garbage, etc.).
	 *
	 * @since 0.11.0
	 */
	accentColors?: AccentColor[];
	/**
	 * Toast-notification type map. Filterable server-side via
	 * `wp_desktop_toast_types`. Optional — same fallback story as
	 * `accentColors`.
	 *
	 * @since 0.11.0
	 */
	toastTypes?: ToastTypeDef[];
	/**
	 * Wallpaper slug applied on first boot for a new user. Filterable
	 * server-side via `wp_desktop_default_wallpaper`. Optional — an
	 * empty string falls back to the TS default.
	 *
	 * @since 0.11.0
	 */
	defaultWallpaper?: string;
	/**
	 * Saved OS settings for the current user, loaded from user meta by PHP
	 * at boot. The JS layer reads this once to hydrate its local state,
	 * then writes to localStorage for instant subsequent reads and POSTs
	 * changes back to `osSettingsUrl` so user meta stays the durable source.
	 *
	 * Optional — absent on older PHP builds that predate this field.
	 *
	 * @since 0.14.0
	 */
	osSettings?: Record<string, unknown>;
	/**
	 * REST endpoint for reading/writing OS settings.
	 * @since 0.14.0
	 */
	osSettingsUrl?: string;
	/**
	 * REST endpoint for the AI content search.
	 * Shape: `wp-desktop/v1/ai/search`.
	 * @since 0.14.0
	 */
	aiSearchUrl?: string;
	/**
	 * SSE streaming endpoint for the agentic search — admin-ajax.php with
	 * `action=wpdm_ai_search_stream` pre-filled. The JS EventSource appends
	 * &nonce= and &query= when connecting.
	 * @since 0.14.0
	 */
	aiSearchStreamUrl?: string;
	/**
	 * Platform-wide AI settings — only present for admins (null for
	 * non-admin users so the key is never leaked in the page source).
	 * @since 0.14.0
	 */
	aiPlatformSettings?: { enabled: boolean; provider: string; apiKey: string } | null;
	/**
	 * REST endpoint for reading/writing platform AI settings (admin only).
	 * @since 0.14.0
	 */
	aiPlatformSettingsUrl?: string;
	/**
	 * Whether the current user has the `manage_options` capability.
	 * @since 0.14.0
	 */
	currentUserIsAdmin?: boolean;
	/**
	 * Platform-wide extended options (admin-only). Contains toggles
	 * for optional site-level enhancements such as Media Library
	 * drag-and-drop. Null for non-admin users.
	 * @since 0.14.0
	 */
	extendedOptions?: { media_library_enhanced: boolean } | null;
	/**
	 * REST endpoint for reading/writing extended options (admin only).
	 * @since 0.14.0
	 */
	extendedOptionsUrl?: string;
}

/**
 * A single entry in the OS Settings accent-color picker.
 *
 * @since 0.11.0
 */
export interface AccentColor {
	id: string;
	label: string;
	value: string;
}

/**
 * A single toast-notification type declared by the server.
 *
 * @since 0.11.0
 */
export interface ToastTypeDef {
	id: string;
	label: string;
	icon: string;
	tone: 'positive' | 'warning' | 'critical' | 'neutral';
}

/**
 * Bridge events sent from iframe to parent shell.
 */
export type BridgeEventFromIframe =
	| { type: 'wp-desktop-title-change'; title: string }
	| { type: 'wp-desktop-navigate'; url: string; target: 'self' | 'new' }
	| { type: 'wp-desktop-notification'; title: string; body: string }
	| { type: 'wp-desktop-ready' }
	| { type: 'wp-desktop-screen-meta'; panels: ( 'screen-options' | 'help' )[] }
	| { type: 'wp-desktop-screen-meta-state'; open: 'screen-options' | 'help' | null };

/**
 * Bridge events sent from parent shell to iframe.
 */
export type BridgeEventToIframe =
	| { type: 'wp-desktop-focus' }
	| { type: 'wp-desktop-color-scheme'; scheme: string }
	| { type: 'wp-desktop-toggle-panel'; panel: 'screen-options' | 'help' };
