/**
 * Desktop Mode — Public API barrel.
 *
 * The single canonical entry point for third-party plugin authors
 * writing TypeScript against the shell. Everything re-exported from
 * here is considered **Stable** unless its doc comment says otherwise:
 * we promise backwards-compatibility within a major version.
 *
 * Anything NOT re-exported from here is shell-internal; its path may
 * change, its shape may change, and its behavior may tighten without
 * notice. If you find yourself reaching into a non-barrel file to get
 * a type or helper that feels author-facing, open an issue — it
 * should either land here or gain a dedicated escape hatch.
 *
 * Usage:
 *
 *   ```ts
 *   import type {
 *     WidgetDef,
 *     WallpaperDef,
 *     WindowConfig,
 *   } from 'wp-desktop-mode';
 *   import { HOOKS } from 'wp-desktop-mode';
 *
 *   wp.desktop.hooks.addAction( HOOKS.WINDOW_OPENED, 'myplugin/track', ( e ) => {
 *     console.log( 'Window opened:', e.windowId );
 *   } );
 *   ```
 *
 * (The `wp-desktop-mode` package name above is aspirational — today
 * plugins are bundled alongside the shell and import relatively. When
 * we publish this as an npm-distributable d.ts bundle, this file is
 * what the `main` field points at.)
 *
 * @since 0.8.2
 */

// ----- Types: windows, desktops, dock, session, config -----

export type {
	Desktop,
	DesktopConfig,
	DockItemConfig,
	MonitorEntry,
	DesktopWallpaperServerEntry,
	DesktopWidgetServerEntry,
	NativeWindowDef,
	NativeWindowServerEntry,
	Session,
	SessionWindow,
	VisibleWindowRect,
	WindowConfig,
	WindowSnapshot,
	WindowState,
	BridgeEventFromIframe,
	BridgeEventToIframe,
} from './types';

// ----- Types: wallpapers -----

export type {
	CanvasWallpaperDef,
	CssWallpaperDef,
	WallpaperContext,
	WallpaperDef,
	WallpaperEditor,
	WallpaperMountResult,
	WallpaperTeardown,
	WallpapersFilter,
} from './wallpapers/types';

// ----- Types: widgets -----

export type {
	WidgetContext,
	WidgetDef,
	WidgetGeometry,
	WidgetTeardown,
} from './widgets/types';

// ----- Types: modules (vendor-script registry) -----

export type { ModuleDef } from './modules/registry';

// ----- Hooks: typed constants + wrappers -----

/**
 * The canonical list of shell-dispatched hook names. Use these
 * constants instead of hand-typed strings so a renamed hook fails
 * typecheck instead of silently going dead.
 *
 * ```ts
 * wp.desktop.hooks.addAction(
 *     wp.desktop.HOOKS.ARRANGE_CASCADE_APPLIED,
 *     'myplugin/toast',
 *     ({ windowCount }) => toast(`Arranged ${windowCount} windows`)
 * );
 * ```
 */
export { HOOKS } from './hooks';

export type { WpHooks } from './hooks';

/**
 * Typed helpers around `window.wp.hooks`. Most plugins should use
 * the untyped bridge at `wp.hooks` directly — these are for authors
 * who want strict signatures on their callbacks.
 */
export {
	addAction,
	addFilter,
	applyFilters,
	didAction,
	doAction,
	rawHooks,
	removeAction,
	removeFilter,
	whenReady,
} from './hooks';

// ----- Public class types (for plugins that need to type-cast an
// instance returned by `wp.desktop.windowManager` / `.dock`) -----

export type { Window } from './window';
export type { WindowManager } from './window-manager';
export type { Dock, DockOrientation, SystemDockItem } from './dock';
export type { WidgetLayer } from './widgets/layer';

// ----- Native window helpers -----

/**
 * Native-window convenience wrappers. `registerWindow` is a compact
 * alias for the boilerplate-heavy `windowManager.open({ native: true, … })`
 * pattern; `cloneTemplate` short-circuits the `<template>`-element
 * cloning dance every native window would otherwise inline.
 */
export {
	cloneTemplate,
	createRegisterWindow,
	onWindow,
} from './native-windows';

export type { WindowLifecycleHandlers } from './native-windows';

// ----- Wallpaper surfaces (collision-aware wallpapers) -----

export type { WallpaperSurface } from './wallpapers/surfaces';

// ----- UI component kit (Stable) -----
//
// Every component listed below defines itself on
// `customElements` via side-effects at import time — importing
// this barrel from a plugin's bundle registers every tag. The
// classes are also named exports so plugins that need to
// subclass or type-assert them can.
//
// Each component is considered **Stable**: attribute names,
// event contracts, and `::part()` anchors won't break within a
// major release without a deprecation notice first.

export {
	WpdButton,
	WpdCheckboxLabel,
	WpdCluster,
	WpdColorField,
	WpdDisplay,
	WpdEmptyState,
	WpdGrid,
	WpdIcon,
	WpdKey,
	WpdMenu,
	WpdMenuItem,
	WpdPanel,
	WpdRangeField,
	WpdSection,
	WpdSegment,
	WpdSegmented,
	WpdStack,
	WpdSwatch,
	WpdSwatchGrid,
	WpdTab,
	WpdTabChip,
	WpdTabs,
	WpdToast,
	WpdToastContainer,
	WpdWindowButton,
} from './ui/components';

// Stable variant enum for <wpd-button> — plugins can narrow props
// against the recognised set rather than hard-coding strings.
export type { WpdButtonVariant } from './ui/components/wpd-button/wpd-button';
