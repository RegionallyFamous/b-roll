/**
 * Constants for the OS Settings module.
 *
 * Kept plain (no i18n) so they can be imported from anywhere —
 * including files that shouldn't pull `@wordpress/i18n` into their
 * dependency graph.
 *
 * Most values are fallbacks. The live set comes from
 * `wpDesktopConfig.accentColors` / `.defaultWallpaper`, populated by
 * PHP via `wp_desktop_accent_colors` / `wp_desktop_default_wallpaper`
 * filters. The getters in this file do the `runtime config → fallback`
 * dance so callers never have to branch on "is the config hydrated?"
 */

import type { AccentColor, DesktopConfig } from '../types';
import type { OsSettingsState } from './types';

/** localStorage key under which preferences are serialized. */
export const STORAGE_KEY = 'wp-desktop-os-settings';

/** Minimum resolution considered "HD" for the wallpaper picker filter. */
export const HD_MIN_WIDTH = 1920;
export const HD_MIN_HEIGHT = 1080;

/** How many media items we ask the REST endpoint for per page. */
export const MEDIA_PER_PAGE = 40;

/** Debounce window for the library search input. */
export const SEARCH_DEBOUNCE_MS = 300;

/** Built-in wallpaper id for the custom-gradient editor. */
export const CUSTOM_GRADIENT_ID = 'custom-gradient';

/** Built-in wallpaper id for uploaded/library-picked images. */
export const CUSTOM_IMAGE_ID = 'custom-image';

/** Default fallback id when a registered wallpaper isn't available. */
export const DEFAULT_WALLPAPER_ID = 'dark';

/**
 * Built-in accent swatches applied to `--wp-admin-theme-color`.
 *
 * This is the compile-time fallback list used when PHP doesn't hand
 * us a live `accentColors` array in `wpDesktopConfig` — the live list
 * is what the picker actually renders. Plugins that want to
 * customise the list should hook `wp_desktop_accent_colors` in PHP,
 * not fork this constant.
 */
export const DEFAULT_ACCENTS: readonly AccentColor[] = [
	{ id: 'wp-blue', label: 'WordPress Blue', value: '#2271b1' },
	{ id: 'indigo', label: 'Indigo', value: '#3858e9' },
	{ id: 'teal', label: 'Teal', value: '#04a4cc' },
	{ id: 'emerald', label: 'Emerald', value: '#059669' },
	{ id: 'amber', label: 'Amber', value: '#d97706' },
	{ id: 'rose', label: 'Rose', value: '#e11d48' },
] as const;

/**
 * Resolve the live accent-color list.
 *
 * Reads `window.wp.desktop.config.accentColors` (populated by PHP via
 * `wp_desktop_accent_colors`) and validates each entry shape. Drops
 * malformed entries rather than letting a bad filter render broken
 * swatches. Falls back to {@link DEFAULT_ACCENTS} when the config is
 * missing or yields zero valid entries.
 *
 * @since 0.11.0
 */
export function getAccents(): readonly AccentColor[] {
	const config = ( window as unknown as {
		wp?: { desktop?: { config?: DesktopConfig } };
	} ).wp?.desktop?.config;
	const raw = config?.accentColors;
	if ( ! Array.isArray( raw ) || raw.length === 0 ) {
		return DEFAULT_ACCENTS;
	}
	const clean: AccentColor[] = [];
	for ( const entry of raw ) {
		if (
			entry &&
			typeof entry === 'object' &&
			typeof entry.id === 'string' &&
			typeof entry.label === 'string' &&
			typeof entry.value === 'string' &&
			entry.id !== '' &&
			entry.label !== '' &&
			/^#[0-9a-f]{3,8}$/i.test( entry.value )
		) {
			clean.push( { id: entry.id, label: entry.label, value: entry.value } );
		}
	}
	return clean.length > 0 ? clean : DEFAULT_ACCENTS;
}

/**
 * Resolve the live default-wallpaper slug. Reads
 * `window.wp.desktop.config.defaultWallpaper` and falls back to
 * {@link DEFAULT_WALLPAPER_ID} when absent/invalid.
 *
 * @since 0.11.0
 */
export function getDefaultWallpaperId(): string {
	const config = ( window as unknown as {
		wp?: { desktop?: { config?: DesktopConfig } };
	} ).wp?.desktop?.config;
	const raw = config?.defaultWallpaper;
	if ( typeof raw === 'string' && raw !== '' ) {
		return raw;
	}
	return DEFAULT_WALLPAPER_ID;
}

/** Dock-size options. Each ships a width in px + icon scale. */
export const DOCK_SIZES = [
	{ id: 'compact', label: 'Compact', width: 48, icon: 18 },
	{ id: 'default', label: 'Default', width: 56, icon: 20 },
	{ id: 'large', label: 'Large', width: 72, icon: 26 },
] as const;

export const DEFAULTS: OsSettingsState = {
	wallpaper: DEFAULT_WALLPAPER_ID,
	accent: 'wp-blue',
	dockSize: 'default',
	customGradient: {
		from: '#2271b1',
		to: '#7c3aed',
		angle: 135,
	},
	customImage: null,
	libraryHdOnly: true,
	ai: {
		enabled: false,
		provider: 'openai',
		apiKey: '',
	},
};

/**
 * Available AI providers. Single-entry for now — the picker is still a
 * `<wpd-select>` so adding the next provider is zero-UI-churn.
 */
export const AI_PROVIDERS = [
	{ id: 'openai' as const, label: 'OpenAI' },
] as const;
